# Implementasi Blade Layout, Controller & Routing
4 template, 24 halaman, masing-masing template punya 1 layout utama.

| Jenis   | Template | Layout                       | Controller                          | Prefix URL | Halaman |
|---------|----------|------------------------------|-------------------------------------|------------|---------|
| Landing | Amping   | `layouts/landing.blade.php`  | `Landing/LandingController`         | `/`        | 6 |
| Admin   | Xeloro   | `layouts/admin.blade.php`    | `Admin/AdminController`             | `/admin`   | 6 |
| Landing | Movflx   | `layouts/movflx.blade.php`   | `Landing/MovflxController`          | `/movflx`  | 6 |
| Admin   | Snacked  | `layouts/snacked.blade.php`  | `Admin/SnackedController`           | `/snacked` | 6 |

## Cara pakai
```bash
composer create-project laravel/laravel nama-proyek
```
Salin `app/`, `resources/`, `routes/`, `public/` dari folder ini ke proyek tadi (timpa `routes/web.php`), lalu:
```bash
cd nama-proyek
php artisan route:list
php artisan serve
```

## Daftar URL
**Amping (landing)**: `/`, `/about`, `/activities`, `/blog`, `/contact`, `/testimonials`
**Xeloro (admin)**: `/admin`, `/admin/tables`, `/admin/forms`, `/admin/calendar`, `/admin/sweetalerts`, `/admin/login`
**Movflx (landing)**: `/movflx`, `/movflx/movie`, `/movflx/tv-show`, `/movflx/pricing`, `/movflx/blog`, `/movflx/contact`
**Snacked (admin)**: `/snacked`, `/snacked/tables`, `/snacked/forms`, `/snacked/charts`, `/snacked/calendar`, `/snacked/login`

## Struktur
```
app/Http/Controllers/{Admin,Landing}/...
routes/web.php
resources/views/
  layouts/        admin | landing | snacked | movflx
  partials/<tpl>/ head, header (+sidebar), footer, scripts
  admin/*.blade.php, admin/snacked/*.blade.php
  landing/*.blade.php, landing/movflx/*.blade.php
public/assets/{admin,landing,snacked,movflx}/
```

## Catatan
- Setiap layout dibagi: Head, Header/Menubar, Main Content, Footer, Scripts.
- CSS/JS khusus halaman memakai `@push('styles')` / `@push('scripts')`
  (Snacked juga punya `@push('scripts_after')` untuk script yang harus dimuat setelah `app.js`).
- Halaman login (Xeloro & Snacked) memakai layout yang sama tanpa sidebar/topbar lewat `@section('standalone')`.
- Snacked tidak punya elemen footer di template aslinya, jadi partial `footer` berisi bagian akhir halaman
  (overlay, tombol back-to-top, theme switcher).
- Link ke halaman template di luar 24 halaman ini diubah menjadi `#`.
