<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;

class AdminController extends Controller
{
    /**
     * Halaman utama -> resources/views/admin/dashboard.blade.php
     */
    public function index()
    {
        return view('admin.dashboard');
    }

    /**
     * Halaman Data Tables -> resources/views/admin/tables.blade.php
     */
    public function tables()
    {
        return view('admin.tables');
    }

    /**
     * Halaman Form Elements -> resources/views/admin/forms.blade.php
     */
    public function forms()
    {
        return view('admin.forms');
    }

    /**
     * Halaman Calendar -> resources/views/admin/calendar.blade.php
     */
    public function calendar()
    {
        return view('admin.calendar');
    }

    /**
     * Halaman Sweet Alerts -> resources/views/admin/sweetalerts.blade.php
     */
    public function sweetalerts()
    {
        return view('admin.sweetalerts');
    }

    /**
     * Halaman Login -> resources/views/admin/login.blade.php
     */
    public function login()
    {
        return view('admin.login');
    }
}
