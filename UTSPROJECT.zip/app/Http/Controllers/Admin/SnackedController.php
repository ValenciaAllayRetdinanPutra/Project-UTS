<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;

class SnackedController extends Controller
{
    /**
     * Halaman utama admin Snacked -> resources/views/admin/snacked/dashboard.blade.php
     */
    public function index()
    {
        return view('admin.snacked.dashboard');
    }

    /**
     * Halaman Data Table -> resources/views/admin/snacked/tables.blade.php
     */
    public function tables()
    {
        return view('admin.snacked.tables');
    }

    /**
     * Halaman Form Elements -> resources/views/admin/snacked/forms.blade.php
     */
    public function forms()
    {
        return view('admin.snacked.forms');
    }

    /**
     * Halaman Apex Charts -> resources/views/admin/snacked/charts.blade.php
     */
    public function charts()
    {
        return view('admin.snacked.charts');
    }

    /**
     * Halaman Calendar -> resources/views/admin/snacked/calendar.blade.php
     */
    public function calendar()
    {
        return view('admin.snacked.calendar');
    }

    /**
     * Halaman Sign In -> resources/views/admin/snacked/login.blade.php
     */
    public function login()
    {
        return view('admin.snacked.login');
    }
}
