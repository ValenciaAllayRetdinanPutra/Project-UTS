<?php

namespace App\Http\Controllers\Landing;

use App\Http\Controllers\Controller;

class LandingController extends Controller
{
    /**
     * Halaman utama -> resources/views/landing/home.blade.php
     */
    public function index()
    {
        return view('landing.home');
    }

    /**
     * Halaman About Us -> resources/views/landing/about.blade.php
     */
    public function about()
    {
        return view('landing.about');
    }

    /**
     * Halaman Activities -> resources/views/landing/activities.blade.php
     */
    public function activities()
    {
        return view('landing.activities');
    }

    /**
     * Halaman Our Blog -> resources/views/landing/blog.blade.php
     */
    public function blog()
    {
        return view('landing.blog');
    }

    /**
     * Halaman Contact -> resources/views/landing/contact.blade.php
     */
    public function contact()
    {
        return view('landing.contact');
    }

    /**
     * Halaman Testimonials -> resources/views/landing/testimonials.blade.php
     */
    public function testimonials()
    {
        return view('landing.testimonials');
    }
}
