<?php

namespace App\Http\Controllers\Landing;

use App\Http\Controllers\Controller;

class MovflxController extends Controller
{
    /**
     * Halaman utama landing Movflx -> resources/views/landing/movflx/home.blade.php
     */
    public function index()
    {
        return view('landing.movflx.home');
    }

    /**
     * Halaman Movie -> resources/views/landing/movflx/movie.blade.php
     */
    public function movie()
    {
        return view('landing.movflx.movie');
    }

    /**
     * Halaman TV Show -> resources/views/landing/movflx/tvshow.blade.php
     */
    public function tvshow()
    {
        return view('landing.movflx.tvshow');
    }

    /**
     * Halaman Pricing -> resources/views/landing/movflx/pricing.blade.php
     */
    public function pricing()
    {
        return view('landing.movflx.pricing');
    }

    /**
     * Halaman Blog -> resources/views/landing/movflx/blog.blade.php
     */
    public function blog()
    {
        return view('landing.movflx.blog');
    }

    /**
     * Halaman Contact -> resources/views/landing/movflx/contact.blade.php
     */
    public function contact()
    {
        return view('landing.movflx.contact');
    }
}
