@extends('layouts.admin')

@section('title', 'Sweet Alerts')

@push('styles')
    <link href="{{ asset('assets/admin/plugins/sweetalert2/sweetalert2.min.css') }}" rel="stylesheet" type="text/css" />
@endpush

@section('content')
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-flex align-items-center justify-content-between">
            <h4 class="mb-0 font-size-18">Sweet Alerts</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">UI Elements</a></li>
                    <li class="breadcrumb-item active">Sweet Alerts</li>
                </ol>
            </div>
            
        </div>
    </div>
</div>     
<!-- end page title -->

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Examples</h4>

                <p class="card-subtitle mb-4">
                    A beautiful, responsive, customizable, accessible (WAI-ARIA) replacement for JavaScript's popup boxes
                </p>

                <div class="row">
                    <div class="col-xl-6">
                        <table class="table table-borderless table-centered mb-0">
                            <thead class="thead-light">
                                <tr>
                                    <th>Alert Type</th>
                                    <th>Example</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>A basic message</td>
                                    <td>
                                        <button type="button" class="btn btn-info btn-sm waves-effect waves-light" id="sa-basic">Click me</button>
                                    </td>
                                </tr>

                                <tr>
                                    <td>A title with a text under</td>
                                    <td>
                                        <button type="button" class="btn btn-info btn-sm waves-effect waves-light" id="sa-title">Click me</button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>A success message!</td>
                                    <td>
                                        <button type="button" class="btn btn-info btn-sm waves-effect waves-light" id="sa-success">Click me</button>
                                    </td>
                                </tr>

                                <tr>
                                    <td>A modal window with a long content inside:</td>
                                    <td>
                                        <button type="button" class="btn btn-info btn-sm waves-effect waves-light" id="sa-long-content">Click me</button>
                                    </td>
                                </tr>

                                <tr>
                                    <td>A custom positioned dialog</td>
                                    <td>
                                        <button type="button" class="btn btn-info btn-sm waves-effect waves-light" id="sa-custom-position">Click me</button>
                                    </td>
                                </tr>

                                <tr>
                                    <td>A modal with a title, an error icon, a text, and a footer</td>
                                    <td>
                                        <button type="button" class="btn btn-info btn-sm waves-effect waves-light" id="sa-error">Click me</button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>A confirm dialog, with a function attached to the "Confirm"-button...</td>
                                    <td>
                                        <button type="button" class="btn btn-info btn-sm waves-effect waves-light" id="sa-warning">Click me</button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>By passing a parameter, you can execute something else for "Cancel".</td>
                                    <td>
                                        <button type="button" class="btn btn-info btn-sm waves-effect waves-light" id="sa-params">Click me</button>
                                    </td>
                                </tr>
                            
                            </tbody>
                        </table>
                    </div> <!-- end col -->
                    <div class="col-xl-6">
                        <table class="table table-borderless table-centered mb-0">
                            <thead class="thead-light">
                                <tr>
                                    <th>Alert Type</th>
                                    <th>Example</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>A message with custom Image Header</td>
                                    <td>
                                        <button type="button" class="btn btn-info btn-sm waves-effect waves-light" id="sa-image">Click me</button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>A message with auto close timer</td>
                                    <td>
                                        <button type="button" class="btn btn-info btn-sm waves-effect waves-light" id="sa-close">Click me</button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Custom HTML description and buttons</td>
                                    <td>
                                        <button type="button" class="btn btn-info btn-sm waves-effect waves-light" id="custom-html-alert">Click me</button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>A message with custom width, padding and background</td>
                                    <td>
                                        <button type="button" class="btn btn-info btn-sm waves-effect waves-light" id="custom-padding-width-alert">Click me</button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Ajax request example</td>
                                    <td>
                                        <button type="button" class="btn btn-info btn-sm waves-effect waves-light" id="ajax-alert">Click me</button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Chaining modals (queue) example</td>
                                    <td>
                                        <button type="button" class="btn btn-info btn-sm waves-effect waves-light" id="chaining-alert">Click me</button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Dynamic queue example</td>
                                    <td>
                                        <button type="button" class="btn btn-info btn-sm waves-effect waves-light" id="dynamic-alert">Click me</button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- end row -->
            </div> <!-- end card-body -->
        </div> <!-- end card-->
    </div>
    <!-- end col -->

</div>
<!-- end row -->



@endsection

@push('scripts')
    <script src="{{ asset('assets/admin/plugins/sweetalert2/sweetalert2.min.js') }}"></script>
    <script src="{{ asset('assets/admin/pages/sweet-alert-demo.js') }}"></script>
@endpush
