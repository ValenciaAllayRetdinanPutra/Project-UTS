<!DOCTYPE html>
<html lang="en">

<head>
    @include('partials.admin.head')
</head>

<body>

    @hasSection('standalone')
        {{-- Halaman tanpa sidebar/topbar (mis. login) --}}
        @yield('content')
    @else
        <!-- Begin page -->
        <div id="layout-wrapper">
            <div class="header-border"></div>

            {{-- HEADER / MENUBAR --}}
            @include('partials.admin.header')
            @include('partials.admin.sidebar')

            {{-- MAIN CONTENT --}}
            <div class="main-content">
                <div class="page-content">
                    <div class="container-fluid">
                        @yield('content')
                    </div>
                </div>

                {{-- FOOTER --}}
                @include('partials.admin.footer')
            </div>
        </div>
        <!-- END layout-wrapper -->

        <!-- Overlay-->
        <div class="menu-overlay"></div>
    @endif

    {{-- SCRIPTS --}}
    @include('partials.admin.scripts')

</body>

</html>
