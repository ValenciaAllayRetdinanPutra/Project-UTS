<!DOCTYPE html>
<html lang="en">

<head>
    @include('partials.landing.head')
</head>

<!-- page wrapper -->
<body>

    <div class="boxed_wrapper">

        {{-- HEADER / MENUBAR --}}
        @include('partials.landing.header')

        {{-- MAIN CONTENT --}}
        @yield('content')

        {{-- FOOTER --}}
        @include('partials.landing.footer')

    </div>

    {{-- SCRIPTS --}}
    @include('partials.landing.scripts')

</body><!-- End of .page_wrapper -->

</html>
