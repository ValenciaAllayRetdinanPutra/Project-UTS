<!doctype html>
<html class="no-js" lang="en">

<head>
    @include('partials.movflx.head')
</head>

<body>

    {{-- HEADER / MENUBAR (termasuk preloader & scroll-top) --}}
    @include('partials.movflx.header')

    {{-- MAIN CONTENT --}}
    <!-- main-area -->
    <main>
        @yield('content')
    </main>
    <!-- main-area-end -->

    {{-- FOOTER --}}
    @include('partials.movflx.footer')

    {{-- SCRIPTS --}}
    @include('partials.movflx.scripts')

</body>

</html>
