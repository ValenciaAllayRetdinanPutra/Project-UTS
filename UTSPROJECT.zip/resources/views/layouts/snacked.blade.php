<!doctype html>
<html lang="en" class="light-theme">

<head>
    @include('partials.snacked.head')
</head>

<body>

    <!--start wrapper-->
    <div class="wrapper">

        @hasSection('standalone')
            {{-- Halaman tanpa sidebar/topbar (mis. login) --}}
            @yield('content')
        @else
            {{-- HEADER / MENUBAR (topbar + sidebar) --}}
            @include('partials.snacked.header')

            {{-- MAIN CONTENT --}}
            <main class="page-content">
                @yield('content')
            </main>

            {{-- FOOTER (overlay, back-to-top, switcher) --}}
            @include('partials.snacked.footer')
        @endif

    </div>
    <!--end wrapper-->

    {{-- SCRIPTS --}}
    @include('partials.snacked.scripts')

</body>

</html>
