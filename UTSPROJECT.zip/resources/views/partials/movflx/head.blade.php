<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<title>@yield('title', 'Home') | Movflx - Online Movies & TV Shows Template</title>
<meta name="description" content="">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="{{ csrf_token() }}">

<link rel="shortcut icon" type="image/x-icon" href="{{ asset('assets/movflx/img/favicon.png') }}">

<!-- CSS here -->
<link rel="stylesheet" href="{{ asset('assets/movflx/css/bootstrap.min.css') }}">
<link rel="stylesheet" href="{{ asset('assets/movflx/css/animate.min.css') }}">
<link rel="stylesheet" href="{{ asset('assets/movflx/css/magnific-popup.css') }}">
<link rel="stylesheet" href="{{ asset('assets/movflx/css/fontawesome-all.min.css') }}">
<link rel="stylesheet" href="{{ asset('assets/movflx/css/owl.carousel.min.css') }}">
<link rel="stylesheet" href="{{ asset('assets/movflx/css/flaticon.css') }}">
<link rel="stylesheet" href="{{ asset('assets/movflx/css/odometer.css') }}">
<link rel="stylesheet" href="{{ asset('assets/movflx/css/aos.css') }}">
<link rel="stylesheet" href="{{ asset('assets/movflx/css/slick.css') }}">
<link rel="stylesheet" href="{{ asset('assets/movflx/css/default.css') }}">
<link rel="stylesheet" href="{{ asset('assets/movflx/css/style.css') }}">
<link rel="stylesheet" href="{{ asset('assets/movflx/css/responsive.css') }}">

{{-- CSS khusus halaman --}}
@stack('styles')
