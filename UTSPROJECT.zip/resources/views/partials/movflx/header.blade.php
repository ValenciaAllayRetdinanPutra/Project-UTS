{{-- Preloader + scroll-top + Header/Menubar Movflx --}}
<!-- preloader -->
<div id="preloader">
    <div id="loading-center">
        <div id="loading-center-absolute">
            <img src="{{ asset('assets/movflx/img/preloader.svg') }}" alt="">
        </div>
    </div>
</div>
<!-- preloader-end -->

<!-- Scroll-top -->
<button class="scroll-top scroll-to-target" data-target="html">
    <i class="fas fa-angle-up"></i>
</button>
<!-- Scroll-top-end-->

<!-- header-area -->
<header>
    <div id="sticky-header" class="menu-area transparent-header">
        <div class="container custom-container">
            <div class="row">
                <div class="col-12">
                    <div class="mobile-nav-toggler"><i class="fas fa-bars"></i></div>
                    <div class="menu-wrap">
                        <nav class="menu-nav show">
                            <div class="logo">
                                <a href="{{ route('movflx.home') }}">
                                    <img src="{{ asset('assets/movflx/img/logo/logo.png') }}" alt="Logo">
                                </a>
                            </div>
                            <div class="navbar-wrap main-menu d-none d-lg-flex">
                                <ul class="navigation">
                                    <li class="{{ request()->routeIs('movflx.home') ? 'active' : '' }} menu-item-has-children"><a href="#">Home</a>
                                        <ul class="submenu">
                                            <li class="{{ request()->routeIs('movflx.home') ? 'active' : '' }}"><a href="{{ route('movflx.home') }}">Home One</a></li>
                                            <li><a href="#">Home Two</a></li>
                                        </ul>
                                    </li>
                                    <li class="{{ request()->routeIs('movflx.movie') ? 'active' : '' }} menu-item-has-children"><a href="#">Movie</a>
                                        <ul class="submenu">
                                            <li class="{{ request()->routeIs('movflx.movie') ? 'active' : '' }}"><a href="{{ route('movflx.movie') }}">Movie</a></li>
                                            <li><a href="#">Movie Details</a></li>
                                        </ul>
                                    </li>
                                    <li class="{{ request()->routeIs('movflx.tvshow') ? 'active' : '' }}"><a href="{{ route('movflx.tvshow') }}">tv show</a></li>
                                    <li class="{{ request()->routeIs('movflx.pricing') ? 'active' : '' }}"><a href="{{ route('movflx.pricing') }}">Pricing</a></li>
                                    <li class="{{ request()->routeIs('movflx.blog') ? 'active' : '' }} menu-item-has-children"><a href="#">blog</a>
                                        <ul class="submenu">
                                            <li class="{{ request()->routeIs('movflx.blog') ? 'active' : '' }}"><a href="{{ route('movflx.blog') }}">Our Blog</a></li>
                                            <li><a href="#">Blog Details</a></li>
                                        </ul>
                                    </li>
                                    <li class="{{ request()->routeIs('movflx.contact') ? 'active' : '' }}"><a href="{{ route('movflx.contact') }}">contacts</a></li>
                                </ul>
                            </div>
                            <div class="header-action d-none d-md-block">
                                <ul>
                                    <li class="header-search"><a href="#" data-toggle="modal" data-target="#search-modal"><i class="fas fa-search"></i></a></li>
                                    <li class="header-lang">
                                        <form action="#">
                                            <div class="icon"><i class="flaticon-globe"></i></div>
                                            <select id="lang-dropdown">
                                                <option value="">En</option>
                                                <option value="">Au</option>
                                                <option value="">AR</option>
                                                <option value="">TU</option>
                                            </select>
                                        </form>
                                    </li>
                                    <li class="header-btn"><a href="#" class="btn">Sign In</a></li>
                                </ul>
                            </div>
                        </nav>
                    </div>

                    <!-- Mobile Menu  -->
                    <div class="mobile-menu">
                        <div class="close-btn"><i class="fas fa-times"></i></div>

                        <nav class="menu-box">
                            <div class="nav-logo"><a href="{{ route('movflx.home') }}"><img src="{{ asset('assets/movflx/img/logo/logo.png') }}" alt="" title=""></a>
                            </div>
                            <div class="menu-outer">
                                <!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
                            </div>
                            <div class="social-links">
                                <ul class="clearfix">
                                    <li><a href="#"><span class="fab fa-twitter"></span></a></li>
                                    <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
                                    <li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
                                    <li><a href="#"><span class="fab fa-instagram"></span></a></li>
                                    <li><a href="#"><span class="fab fa-youtube"></span></a></li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                    <div class="menu-backdrop"></div>
                    <!-- End Mobile Menu -->

                    <!-- Modal Search -->
                    <div class="modal fade" id="search-modal" tabindex="-1" role="dialog" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <form>
                                    <input type="text" placeholder="Search here...">
                                    <button><i class="fas fa-search"></i></button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!-- Modal Search-end -->

                </div>
            </div>
        </div>
    </div>
</header>
<!-- header-area-end -->
