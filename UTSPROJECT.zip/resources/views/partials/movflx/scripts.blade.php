<!-- JS here -->
<script src="{{ asset('assets/movflx/js/vendor/jquery-3.6.0.min.js') }}"></script>
<script src="{{ asset('assets/movflx/js/popper.min.js') }}"></script>
<script src="{{ asset('assets/movflx/js/bootstrap.min.js') }}"></script>
<script src="{{ asset('assets/movflx/js/isotope.pkgd.min.js') }}"></script>
<script src="{{ asset('assets/movflx/js/imagesloaded.pkgd.min.js') }}"></script>
<script src="{{ asset('assets/movflx/js/jquery.magnific-popup.min.js') }}"></script>
<script src="{{ asset('assets/movflx/js/owl.carousel.min.js') }}"></script>
<script src="{{ asset('assets/movflx/js/jquery.odometer.min.js') }}"></script>
<script src="{{ asset('assets/movflx/js/jquery.appear.js') }}"></script>
<script src="{{ asset('assets/movflx/js/slick.min.js') }}"></script>
<script src="{{ asset('assets/movflx/js/ajax-form.js') }}"></script>
<script src="{{ asset('assets/movflx/js/wow.min.js') }}"></script>
<script src="{{ asset('assets/movflx/js/aos.js') }}"></script>
<script src="{{ asset('assets/movflx/js/plugins.js') }}"></script>

{{-- JS khusus halaman --}}
@stack('scripts')

<script src="{{ asset('assets/movflx/js/main.js') }}"></script>
