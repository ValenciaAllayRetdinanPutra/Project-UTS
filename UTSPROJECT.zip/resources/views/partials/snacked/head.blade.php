<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="{{ csrf_token() }}">
<link rel="icon" href="{{ asset('assets/snacked/images/favicon-32x32.png') }}" type="image/png" />
<!--plugins-->
<link href="{{ asset('assets/snacked/plugins/simplebar/css/simplebar.css') }}" rel="stylesheet" />
<link href="{{ asset('assets/snacked/plugins/perfect-scrollbar/css/perfect-scrollbar.css') }}" rel="stylesheet" />
<link href="{{ asset('assets/snacked/plugins/metismenu/css/metisMenu.min.css') }}" rel="stylesheet" />
{{-- CSS plugin khusus halaman --}}
@stack('styles')
<!-- Bootstrap CSS -->
<link href="{{ asset('assets/snacked/css/bootstrap.min.css') }}" rel="stylesheet" />
<link href="{{ asset('assets/snacked/css/bootstrap-extended.css') }}" rel="stylesheet" />
<link href="{{ asset('assets/snacked/css/style.css') }}" rel="stylesheet" />
<link href="{{ asset('assets/snacked/css/icons.css') }}" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">

<!-- loader-->
<link href="{{ asset('assets/snacked/css/pace.min.css') }}" rel="stylesheet" />

<!--Theme Styles-->
<link href="{{ asset('assets/snacked/css/dark-theme.css') }}" rel="stylesheet" />
<link href="{{ asset('assets/snacked/css/light-theme.css') }}" rel="stylesheet" />
<link href="{{ asset('assets/snacked/css/semi-dark.css') }}" rel="stylesheet" />
<link href="{{ asset('assets/snacked/css/header-colors.css') }}" rel="stylesheet" />

<title>@yield('title', 'Dashboard') | Snacked - Bootstrap 5 Admin Template</title>
