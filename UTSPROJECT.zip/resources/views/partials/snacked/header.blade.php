{{-- Topbar + Sidebar (menubar) Snacked --}}
<header class="top-header">        
    <nav class="navbar navbar-expand gap-3">
      <div class="mobile-toggle-icon fs-3">
          <i class="bi bi-list"></i>
        </div>
        <form class="searchbar">
            <div class="position-absolute top-50 translate-middle-y search-icon ms-3"><i class="bi bi-search"></i></div>
            <input class="form-control" type="text" placeholder="Type here to search">
            <div class="position-absolute top-50 translate-middle-y search-close-icon"><i class="bi bi-x-lg"></i></div>
        </form>
        <div class="top-navbar-right ms-auto">
          <ul class="navbar-nav align-items-center">
            <li class="nav-item search-toggle-icon">
              <a class="nav-link" href="#">
                <div class="">
                  <i class="bi bi-search"></i>
                </div>
              </a>
          </li>
          <li class="nav-item dropdown dropdown-user-setting">
            <a class="nav-link dropdown-toggle dropdown-toggle-nocaret" href="#" data-bs-toggle="dropdown">
              <div class="user-setting d-flex align-items-center">
                <img src="https://via.placeholder.com/110X110" class="user-img" alt="">
              </div>
            </a>
            <ul class="dropdown-menu dropdown-menu-end">
              <li>
                 <a class="dropdown-item" href="#">
                   <div class="d-flex align-items-center">
                      <img src="https://via.placeholder.com/110X110" alt="" class="rounded-circle" width="54" height="54">
                      <div class="ms-3">
                        <h6 class="mb-0 dropdown-user-name">Jhon Deo</h6>
                        <small class="mb-0 dropdown-user-designation text-secondary">HR Manager</small>
                      </div>
                   </div>
                 </a>
               </li>
               <li><hr class="dropdown-divider"></li>
               <li>
                  <a class="dropdown-item" href="#">
                     <div class="d-flex align-items-center">
                       <div class=""><i class="bi bi-person-fill"></i></div>
                       <div class="ms-3"><span>Profile</span></div>
                     </div>
                   </a>
                </li>
                <li>
                  <a class="dropdown-item" href="#">
                     <div class="d-flex align-items-center">
                       <div class=""><i class="bi bi-gear-fill"></i></div>
                       <div class="ms-3"><span>Setting</span></div>
                     </div>
                   </a>
                </li>
                <li>
                  <a class="dropdown-item" href="#">
                     <div class="d-flex align-items-center">
                       <div class=""><i class="bi bi-speedometer"></i></div>
                       <div class="ms-3"><span>Dashboard</span></div>
                     </div>
                   </a>
                </li>
                <li>
                  <a class="dropdown-item" href="#">
                     <div class="d-flex align-items-center">
                       <div class=""><i class="bi bi-piggy-bank-fill"></i></div>
                       <div class="ms-3"><span>Earnings</span></div>
                     </div>
                   </a>
                </li>
                <li>
                  <a class="dropdown-item" href="#">
                     <div class="d-flex align-items-center">
                       <div class=""><i class="bi bi-cloud-arrow-down-fill"></i></div>
                       <div class="ms-3"><span>Downloads</span></div>
                     </div>
                   </a>
                </li>
                <li><hr class="dropdown-divider"></li>
                <li>
                  <a class="dropdown-item" href="#">
                     <div class="d-flex align-items-center">
                       <div class=""><i class="bi bi-lock-fill"></i></div>
                       <div class="ms-3"><span>Logout</span></div>
                     </div>
                   </a>
                </li>
            </ul>
          </li>
          <li class="nav-item dropdown dropdown-large">
            <a class="nav-link dropdown-toggle dropdown-toggle-nocaret" href="#" data-bs-toggle="dropdown">
              <div class="projects">
                <i class="bi bi-grid-3x3-gap-fill"></i>
              </div>
            </a>
            <div class="dropdown-menu dropdown-menu-end">
               <div class="row row-cols-3 gx-2">
                  <div class="col">
                    <a href="#">
                     <div class="apps p-2 radius-10 text-center">
                        <div class="apps-icon-box mb-1 text-white bg-gradient-purple">
                          <i class="bi bi-basket2-fill"></i>
                        </div>
                        <p class="mb-0 apps-name">Orders</p>
                     </div>
                    </a>
                  </div>
                  <div class="col">
                    <a href="javascript:;">
                    <div class="apps p-2 radius-10 text-center">
                       <div class="apps-icon-box mb-1 text-white bg-gradient-info">
                        <i class="bi bi-people-fill"></i>
                       </div>
                       <p class="mb-0 apps-name">Users</p>
                    </div>
                  </a>
                 </div>
                 <div class="col">
                  <a href="#">
                  <div class="apps p-2 radius-10 text-center">
                     <div class="apps-icon-box mb-1 text-white bg-gradient-success">
                      <i class="bi bi-trophy-fill"></i>
                     </div>
                     <p class="mb-0 apps-name">Products</p>
                  </div>
                  </a>
                </div>
                <div class="col">
                  <a href="#">
                  <div class="apps p-2 radius-10 text-center">
                     <div class="apps-icon-box mb-1 text-white bg-gradient-danger">
                      <i class="bi bi-collection-play-fill"></i>
                     </div>
                     <p class="mb-0 apps-name">Media</p>
                  </div>
                  </a>
                </div>
                <div class="col">
                  <a href="#">
                  <div class="apps p-2 radius-10 text-center">
                     <div class="apps-icon-box mb-1 text-white bg-gradient-warning">
                      <i class="bi bi-person-circle"></i>
                     </div>
                     <p class="mb-0 apps-name">Account</p>
                   </div>
                  </a>
                </div>
                <div class="col">
                  <a href="javascript:;">
                  <div class="apps p-2 radius-10 text-center">
                     <div class="apps-icon-box mb-1 text-white bg-gradient-voilet">
                      <i class="bi bi-file-earmark-text-fill"></i>
                     </div>
                     <p class="mb-0 apps-name">Docs</p>
                  </div>
                  </a>
                </div>
                <div class="col">
                  <a href="#">
                  <div class="apps p-2 radius-10 text-center">
                     <div class="apps-icon-box mb-1 text-white bg-gradient-branding">
                      <i class="bi bi-credit-card-fill"></i>
                     </div>
                     <p class="mb-0 apps-name">Payment</p>
                  </div>
                  </a>
                </div>
                <div class="col">
                  <a href="javascript:;">
                  <div class="apps p-2 radius-10 text-center">
                     <div class="apps-icon-box mb-1 text-white bg-gradient-desert">
                      <i class="bi bi-calendar-check-fill"></i>
                     </div>
                     <p class="mb-0 apps-name">Events</p>
                  </div>
                </a>
                </div>
                <div class="col">
                  <a href="javascript:;">
                  <div class="apps p-2 radius-10 text-center">
                     <div class="apps-icon-box mb-1 text-white bg-gradient-amour">
                      <i class="bi bi-book-half"></i>
                     </div>
                     <p class="mb-0 apps-name">Story</p>
                    </div>
                  </a>
                </div>
               </div><!--end row-->
            </div>
          </li>
          <li class="nav-item dropdown dropdown-large">
            <a class="nav-link dropdown-toggle dropdown-toggle-nocaret" href="#" data-bs-toggle="dropdown">
              <div class="messages">
                <span class="notify-badge">5</span>
                <i class="bi bi-chat-right-fill"></i>
              </div>
            </a>
            <div class="dropdown-menu dropdown-menu-end p-0">
              <div class="p-2 border-bottom m-2">
                  <h5 class="h5 mb-0">Messages</h5>
              </div>
             <div class="header-message-list p-2">
                 <a class="dropdown-item" href="#">
                   <div class="d-flex align-items-center">
                      <img src="https://via.placeholder.com/110X110" alt="" class="rounded-circle" width="50" height="50">
                      <div class="ms-3 flex-grow-1">
                        <h6 class="mb-0 dropdown-msg-user">Amelio Joly <span class="msg-time float-end text-secondary">1 m</span></h6>
                        <small class="mb-0 dropdown-msg-text text-secondary d-flex align-items-center">The standard chunk of lorem...</small>
                      </div>
                   </div>
                 </a>
                <a class="dropdown-item" href="#">
                  <div class="d-flex align-items-center">
                     <img src="https://via.placeholder.com/110X110" alt="" class="rounded-circle" width="50" height="50">
                     <div class="ms-3 flex-grow-1">
                       <h6 class="mb-0 dropdown-msg-user">Althea Cabardo <span class="msg-time float-end text-secondary">7 m</span></h6>
                       <small class="mb-0 dropdown-msg-text text-secondary d-flex align-items-center">Many desktop publishing</small>
                     </div>
                  </div>
                </a>
                <a class="dropdown-item" href="#">
                  <div class="d-flex align-items-center">
                     <img src="https://via.placeholder.com/110X110" alt="" class="rounded-circle" width="50" height="50">
                     <div class="ms-3 flex-grow-1">
                       <h6 class="mb-0 dropdown-msg-user">Katherine Pechon <span class="msg-time float-end text-secondary">2 h</span></h6>
                       <small class="mb-0 dropdown-msg-text text-secondary d-flex align-items-center">Making this the first true</small>
                     </div>
                  </div>
                </a>
                <a class="dropdown-item" href="#">
                  <div class="d-flex align-items-center">
                     <img src="https://via.placeholder.com/110X110" alt="" class="rounded-circle" width="50" height="50">
                     <div class="ms-3 flex-grow-1">
                       <h6 class="mb-0 dropdown-msg-user">Peter Costanzo <span class="msg-time float-end text-secondary">3 h</span></h6>
                       <small class="mb-0 dropdown-msg-text text-secondary d-flex align-items-center">It was popularised in the 1960</small>
                     </div>
                  </div>
                </a>
                <a class="dropdown-item" href="#">
                  <div class="d-flex align-items-center">
                     <img src="https://via.placeholder.com/110X110" alt="" class="rounded-circle" width="50" height="50">
                     <div class="ms-3 flex-grow-1">
                       <h6 class="mb-0 dropdown-msg-user">Thomas Wheeler <span class="msg-time float-end text-secondary">1 d</span></h6>
                       <small class="mb-0 dropdown-msg-text text-secondary d-flex align-items-center">If you are going to use a passage</small>
                     </div>
                  </div>
                </a>
                <a class="dropdown-item" href="#">
                  <div class="d-flex align-items-center">
                     <img src="https://via.placeholder.com/110X110" alt="" class="rounded-circle" width="50" height="50">
                     <div class="ms-3 flex-grow-1">
                       <h6 class="mb-0 dropdown-msg-user">Johnny Seitz <span class="msg-time float-end text-secondary">2 w</span></h6>
                       <small class="mb-0 dropdown-msg-text text-secondary d-flex align-items-center">All the Lorem Ipsum generators</small>
                     </div>
                  </div>
                </a>
                <a class="dropdown-item" href="#">
                  <div class="d-flex align-items-center">
                     <img src="https://via.placeholder.com/110X110" alt="" class="rounded-circle" width="50" height="50">
                     <div class="ms-3 flex-grow-1">
                       <h6 class="mb-0 dropdown-msg-user">Amelio Joly <span class="msg-time float-end text-secondary">1 m</span></h6>
                       <small class="mb-0 dropdown-msg-text text-secondary d-flex align-items-center">The standard chunk of lorem...</small>
                     </div>
                  </div>
                </a>
               <a class="dropdown-item" href="#">
                 <div class="d-flex align-items-center">
                    <img src="https://via.placeholder.com/110X110" alt="" class="rounded-circle" width="50" height="50">
                    <div class="ms-3 flex-grow-1">
                      <h6 class="mb-0 dropdown-msg-user">Althea Cabardo <span class="msg-time float-end text-secondary">7 m</span></h6>
                      <small class="mb-0 dropdown-msg-text text-secondary d-flex align-items-center">Many desktop publishing</small>
                    </div>
                 </div>
               </a>
               <a class="dropdown-item" href="#">
                 <div class="d-flex align-items-center">
                    <img src="https://via.placeholder.com/110X110" alt="" class="rounded-circle" width="50" height="50">
                    <div class="ms-3 flex-grow-1">
                      <h6 class="mb-0 dropdown-msg-user">Katherine Pechon <span class="msg-time float-end text-secondary">2 h</span></h6>
                      <small class="mb-0 dropdown-msg-text text-secondary d-flex align-items-center">Making this the first true</small>
                    </div>
                 </div>
               </a>
            </div>
            <div class="p-2">
              <div><hr class="dropdown-divider"></div>
                <a class="dropdown-item" href="#">
                  <div class="text-center">View All Messages</div>
                </a>
            </div>
           </div>
          </li>
          <li class="nav-item dropdown dropdown-large">
            <a class="nav-link dropdown-toggle dropdown-toggle-nocaret" href="#" data-bs-toggle="dropdown">
              <div class="notifications">
                <span class="notify-badge">8</span>
                <i class="bi bi-bell-fill"></i>
              </div>
            </a>
            <div class="dropdown-menu dropdown-menu-end p-0">
              <div class="p-2 border-bottom m-2">
                  <h5 class="h5 mb-0">Notifications</h5>
              </div>
              <div class="header-notifications-list p-2">
                  <a class="dropdown-item" href="#">
                    <div class="d-flex align-items-center">
                       <div class="notification-box bg-light-primary text-primary"><i class="bi bi-basket2-fill"></i></div>
                       <div class="ms-3 flex-grow-1">
                         <h6 class="mb-0 dropdown-msg-user">New Orders <span class="msg-time float-end text-secondary">1 m</span></h6>
                         <small class="mb-0 dropdown-msg-text text-secondary d-flex align-items-center">You have recived new orders</small>
                       </div>
                    </div>
                  </a>
                 <a class="dropdown-item" href="#">
                   <div class="d-flex align-items-center">
                    <div class="notification-box bg-light-purple text-purple"><i class="bi bi-people-fill"></i></div>
                      <div class="ms-3 flex-grow-1">
                        <h6 class="mb-0 dropdown-msg-user">New Customers <span class="msg-time float-end text-secondary">7 m</span></h6>
                        <small class="mb-0 dropdown-msg-text text-secondary d-flex align-items-center">5 new user registered</small>
                      </div>
                   </div>
                 </a>
                 <a class="dropdown-item" href="#">
                   <div class="d-flex align-items-center">
                    <div class="notification-box bg-light-success text-success"><i class="bi bi-file-earmark-bar-graph-fill"></i></div>
                      <div class="ms-3 flex-grow-1">
                        <h6 class="mb-0 dropdown-msg-user">24 PDF File <span class="msg-time float-end text-secondary">2 h</span></h6>
                        <small class="mb-0 dropdown-msg-text text-secondary d-flex align-items-center">The pdf files generated</small>
                      </div>
                   </div>
                 </a>
                 <a class="dropdown-item" href="#">
                   <div class="d-flex align-items-center">
                    <div class="notification-box bg-light-orange text-orange"><i class="bi bi-collection-play-fill"></i></div>
                      <div class="ms-3 flex-grow-1">
                        <h6 class="mb-0 dropdown-msg-user">Time Response  <span class="msg-time float-end text-secondary">3 h</span></h6>
                        <small class="mb-0 dropdown-msg-text text-secondary d-flex align-items-center">5.1 min avarage time response</small>
                      </div>
                   </div>
                 </a>
                 <a class="dropdown-item" href="#">
                   <div class="d-flex align-items-center">
                    <div class="notification-box bg-light-info text-info"><i class="bi bi-cursor-fill"></i></div>
                      <div class="ms-3 flex-grow-1">
                        <h6 class="mb-0 dropdown-msg-user">New Product Approved  <span class="msg-time float-end text-secondary">1 d</span></h6>
                        <small class="mb-0 dropdown-msg-text text-secondary d-flex align-items-center">Your new product has approved</small>
                      </div>
                   </div>
                 </a>
                 <a class="dropdown-item" href="#">
                   <div class="d-flex align-items-center">
                    <div class="notification-box bg-light-pink text-pink"><i class="bi bi-gift-fill"></i></div>
                      <div class="ms-3 flex-grow-1">
                        <h6 class="mb-0 dropdown-msg-user">New Comments <span class="msg-time float-end text-secondary">2 w</span></h6>
                        <small class="mb-0 dropdown-msg-text text-secondary d-flex align-items-center">New customer comments recived</small>
                      </div>
                   </div>
                 </a>
                 <a class="dropdown-item" href="#">
                   <div class="d-flex align-items-center">
                    <div class="notification-box bg-light-warning text-warning"><i class="bi bi-droplet-fill"></i></div>
                      <div class="ms-3 flex-grow-1">
                        <h6 class="mb-0 dropdown-msg-user">New 24 authors<span class="msg-time float-end text-secondary">1 m</span></h6>
                        <small class="mb-0 dropdown-msg-text text-secondary d-flex align-items-center">24 new authors joined last week</small>
                      </div>
                   </div>
                 </a>
                <a class="dropdown-item" href="#">
                  <div class="d-flex align-items-center">
                    <div class="notification-box bg-light-primary text-primary"><i class="bi bi-mic-fill"></i></div>
                     <div class="ms-3 flex-grow-1">
                       <h6 class="mb-0 dropdown-msg-user">Your item is shipped <span class="msg-time float-end text-secondary">7 m</span></h6>
                       <small class="mb-0 dropdown-msg-text text-secondary d-flex align-items-center">Successfully shipped your item</small>
                     </div>
                  </div>
                </a>
                <a class="dropdown-item" href="#">
                  <div class="d-flex align-items-center">
                    <div class="notification-box bg-light-success text-success"><i class="bi bi-lightbulb-fill"></i></div>
                     <div class="ms-3 flex-grow-1">
                       <h6 class="mb-0 dropdown-msg-user">Defense Alerts <span class="msg-time float-end text-secondary">2 h</span></h6>
                       <small class="mb-0 dropdown-msg-text text-secondary d-flex align-items-center">45% less alerts last 4 weeks</small>
                     </div>
                  </div>
                </a>
                <a class="dropdown-item" href="#">
                  <div class="d-flex align-items-center">
                    <div class="notification-box bg-light-info text-info"><i class="bi bi-bookmark-heart-fill"></i></div>
                     <div class="ms-3 flex-grow-1">
                       <h6 class="mb-0 dropdown-msg-user">4 New Sign Up <span class="msg-time float-end text-secondary">2 w</span></h6>
                       <small class="mb-0 dropdown-msg-text text-secondary d-flex align-items-center">New 4 user registartions</small>
                     </div>
                  </div>
                </a>
                <a class="dropdown-item" href="#">
                  <div class="d-flex align-items-center">
                    <div class="notification-box bg-light-bronze text-bronze"><i class="bi bi-briefcase-fill"></i></div>
                     <div class="ms-3 flex-grow-1">
                       <h6 class="mb-0 dropdown-msg-user">All Documents Uploaded <span class="msg-time float-end text-secondary">1 mo</span></h6>
                       <small class="mb-0 dropdown-msg-text text-secondary d-flex align-items-center">Sussessfully uploaded all files</small>
                     </div>
                  </div>
                </a>
             </div>
             <div class="p-2">
               <div><hr class="dropdown-divider"></div>
                 <a class="dropdown-item" href="#">
                   <div class="text-center">View All Notifications</div>
                 </a>
             </div>
            </div>
          </li>
          </ul>
          </div>
    </nav>
  </header>

<aside class="sidebar-wrapper" data-simplebar="true">
      <div class="sidebar-header">
        <div>
          <img src="{{ asset('assets/snacked/images/logo-icon.png') }}" class="logo-icon" alt="logo icon">
        </div>
        <div>
          <h4 class="logo-text">Snacked</h4>
        </div>
        <div class="toggle-icon ms-auto"> <i class="bi bi-list"></i>
        </div>
      </div>
      <!--navigation-->
      <ul class="metismenu" id="menu">
        <li>
          <a href="javascript:;" class="has-arrow">
            <div class="parent-icon"><i class="bi bi-house-fill"></i>
            </div>
            <div class="menu-title">Dashboard</div>
          </a>
          <ul>
            <li> <a href="{{ route('snacked.dashboard') }}"><i class="bi bi-circle"></i>Blue Dashboard</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Color Dashboard</a>
            </li>
          </ul>
        </li>
        <li>
          <a href="javascript:;" class="has-arrow">
            <div class="parent-icon"><i class="bi bi-grid-fill"></i>
            </div>
            <div class="menu-title">Application</div>
          </a>
          <ul>
            <li> <a href="#"><i class="bi bi-circle"></i>Email</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Chat Box</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>File Manager</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Todo List</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Invoice</a>
            </li>
            <li> <a href="{{ route('snacked.calendar') }}"><i class="bi bi-circle"></i>Calendar</a>
            </li>
          </ul>
        </li>
        <li class="menu-label">UI Elements</li>
        <li>
          <a href="javascript:;" class="has-arrow">
            <div class="parent-icon"><i class="bi bi-droplet-fill"></i>
            </div>
            <div class="menu-title">Widgets</div>
          </a>
          <ul>
            <li> <a href="#"><i class="bi bi-circle"></i>Static Widgets</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Data Widgets</a>
            </li>
          </ul>
        </li>
        <li>
          <a href="javascript:;" class="has-arrow">
            <div class="parent-icon"><i class="bi bi-basket2-fill"></i>
            </div>
            <div class="menu-title">eCommerce</div>
          </a>
          <ul>
            <li> <a href="#"><i class="bi bi-circle"></i>Products List</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Products Grid</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Categories</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Orders</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Order details</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Add New Product</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Add New Product 2</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Transactions</a>
            </li>
          </ul>
        </li>
        <li>
          <a class="has-arrow" href="javascript:;">
            <div class="parent-icon"><i class="bi bi-award-fill"></i>
            </div>
            <div class="menu-title">Components</div>
          </a>
          <ul>
            <li> <a href="#"><i class="bi bi-circle"></i>Alerts</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Accordions</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Badges</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Buttons</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Cards</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Carousels</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>List Groups</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Media Objects</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Modals</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Navs & Tabs</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Navbar</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Pagination</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Popovers & Tooltips</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Progress</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Spinners</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Notifications</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Avatrs & Chips</a>
            </li>
          </ul>
        </li>
        <li>
          <a class="has-arrow" href="javascript:;">
            <div class="parent-icon"><i class="bi bi-cloud-arrow-down-fill"></i>
            </div>
            <div class="menu-title">Icons</div>
          </a>
          <ul>
            <li> <a href="#"><i class="bi bi-circle"></i>Line Icons</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Boxicons</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Feather Icons</a>
            </li>
          </ul>
        </li>
        <li class="menu-label">Forms & Tables</li>
        <li>
          <a class="has-arrow" href="javascript:;">
            <div class="parent-icon"><i class="bi bi-file-earmark-break-fill"></i>
            </div>
            <div class="menu-title">Forms</div>
          </a>
          <ul>
            <li> <a href="{{ route('snacked.forms') }}"><i class="bi bi-circle"></i>Form Elements</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Input Groups</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Forms Layouts</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Form Validation</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Form Wizard</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Date Pickers</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Select2</a>
            </li>
          </ul>
        </li>
        <li>
          <a class="has-arrow" href="javascript:;">
            <div class="parent-icon"><i class="bi bi-file-earmark-spreadsheet-fill"></i>
            </div>
            <div class="menu-title">Tables</div>
          </a>
          <ul>
            <li> <a href="#"><i class="bi bi-circle"></i>Basic Table</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Advance Tables</a>
            </li>
            <li> <a href="{{ route('snacked.tables') }}"><i class="bi bi-circle"></i>Data Table</a>
            </li>
          </ul>
        </li>
        <li class="menu-label">Pages</li>
        <li>
          <a class="has-arrow" href="javascript:;">
            <div class="parent-icon"><i class="bi bi-lock-fill"></i>
            </div>
            <div class="menu-title">Authentication</div>
          </a>
          <ul>
            <li> <a href="{{ route('snacked.login') }}" target="_blank"><i class="bi bi-circle"></i>Sign In</a>
            </li>
            <li> <a href="#" target="_blank"><i class="bi bi-circle"></i>Sign Up</a>
            </li>
            <li> <a href="#" target="_blank"><i class="bi bi-circle"></i>Sign In with Header & Footer</a>
            </li>
            <li> <a href="#" target="_blank"><i class="bi bi-circle"></i>Sign Up with Header & Footer</a>
            </li>
            <li> <a href="#" target="_blank"><i class="bi bi-circle"></i>Forgot Password</a>
            </li>
            <li> <a href="#" target="_blank"><i class="bi bi-circle"></i>Reset Password</a>
            </li>
          </ul>
        </li>
        <li>
          <a href="#">
            <div class="parent-icon"><i class="bi bi-person-lines-fill"></i>
            </div>
            <div class="menu-title">User Profile</div>
          </a>
        </li>
        <li>
          <a href="#">
            <div class="parent-icon"><i class="bi bi-collection-play-fill"></i>
            </div>
            <div class="menu-title">Timeline</div>
          </a>
        </li>
        <li>
          <a class="has-arrow" href="javascript:;">
            <div class="parent-icon"><i class="bi bi-exclamation-triangle-fill"></i>
            </div>
            <div class="menu-title">Errors</div>
          </a>
          <ul>
            <li> <a href="#" target="_blank"><i class="bi bi-circle"></i>404 Error</a>
            </li>
            <li> <a href="#" target="_blank"><i class="bi bi-circle"></i>500 Error</a>
            </li>
            <li> <a href="#" target="_blank"><i class="bi bi-circle"></i>Coming Soon</a>
            </li>
            <li> <a href="#" target="_blank"><i class="bi bi-circle"></i>Blank Page</a>
            </li>
          </ul>
        </li>
        <li>
          <a href="#">
            <div class="parent-icon"><i class="bi bi-question-lg"></i>
            </div>
            <div class="menu-title">FAQ</div>
          </a>
        </li>
        <li>
          <a href="#">
            <div class="parent-icon"><i class="bi bi-tags-fill"></i>
            </div>
            <div class="menu-title">Pricing Tables</div>
          </a>
        </li>
        <li class="menu-label">Charts & Maps</li>
        <li>
          <a class="has-arrow" href="javascript:;">
            <div class="parent-icon"><i class="bi bi-bar-chart-line-fill"></i>
            </div>
            <div class="menu-title">Charts</div>
          </a>
          <ul>
            <li> <a href="{{ route('snacked.charts') }}"><i class="bi bi-circle"></i>Apex</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Chartjs</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Highcharts</a>
            </li>
          </ul>
        </li>
        <li>
          <a class="has-arrow" href="javascript:;">
            <div class="parent-icon"><i class="bi bi-pin-map-fill"></i>
            </div>
            <div class="menu-title">Maps</div>
          </a>
          <ul>
            <li> <a href="#"><i class="bi bi-circle"></i>Google Maps</a>
            </li>
            <li> <a href="#"><i class="bi bi-circle"></i>Vector Maps</a>
            </li>
          </ul>
        </li>
        <li class="menu-label">Others</li>
        <li>
          <a class="has-arrow" href="javascript:;">
            <div class="parent-icon"><i class="bi bi-music-note-list"></i>
            </div>
            <div class="menu-title">Menu Levels</div>
          </a>
          <ul>
            <li> <a class="has-arrow" href="javascript:;"><i class="bi bi-circle"></i>Level One</a>
              <ul>
                <li> <a class="has-arrow" href="javascript:;"><i class="bi bi-circle"></i>Level Two</a>
                  <ul>
                    <li> <a href="javascript:;"><i class="bi bi-circle"></i>Level Three</a>
                    </li>
                  </ul>
                </li>
              </ul>
            </li>
          </ul>
        </li>
        <li>
          <a href="https://codervent.com/skodash/documentation/index.html" target="_blank">
            <div class="parent-icon"><i class="bi bi-file-code-fill"></i>
            </div>
            <div class="menu-title">Documentation</div>
          </a>
        </li>
        <li>
          <a href="https://themeforest.net/user/codervent" target="_blank">
            <div class="parent-icon"><i class="bi bi-telephone-fill"></i>
            </div>
            <div class="menu-title">Support</div>
          </a>
        </li>
      </ul>
      <!--end navigation-->
   </aside>
