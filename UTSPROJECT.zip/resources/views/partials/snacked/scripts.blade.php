@hasSection('standalone')
    {{-- Halaman login: hanya butuh jQuery + pace --}}
    <script src="{{ asset('assets/snacked/js/jquery.min.js') }}"></script>
    <script src="{{ asset('assets/snacked/js/pace.min.js') }}"></script>
@else
    <!-- Bootstrap bundle JS -->
    <script src="{{ asset('assets/snacked/js/bootstrap.bundle.min.js') }}"></script>
    <!--plugins-->
    <script src="{{ asset('assets/snacked/js/jquery.min.js') }}"></script>
    <script src="{{ asset('assets/snacked/plugins/simplebar/js/simplebar.min.js') }}"></script>
    <script src="{{ asset('assets/snacked/plugins/metismenu/js/metisMenu.min.js') }}"></script>
    <script src="{{ asset('assets/snacked/plugins/perfect-scrollbar/js/perfect-scrollbar.js') }}"></script>
    <script src="{{ asset('assets/snacked/js/pace.min.js') }}"></script>

    {{-- Plugin JS khusus halaman (sebelum app.js) --}}
    @stack('scripts')

    <!--app-->
    <script src="{{ asset('assets/snacked/js/app.js') }}"></script>

    {{-- JS khusus halaman yang harus dimuat setelah app.js --}}
    @stack('scripts_after')
@endif
