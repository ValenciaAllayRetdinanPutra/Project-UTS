<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\AdminController;
use App\Http\Controllers\Landing\LandingController;
use App\Http\Controllers\Admin\SnackedController;
use App\Http\Controllers\Landing\MovflxController;

/*
|--------------------------------------------------------------------------
| Landing Page (template Amping)
|--------------------------------------------------------------------------
*/

Route::get('/', [LandingController::class, 'index'])->name('landing.home');
Route::get('/about', [LandingController::class, 'about'])->name('landing.about');
Route::get('/activities', [LandingController::class, 'activities'])->name('landing.activities');
Route::get('/blog', [LandingController::class, 'blog'])->name('landing.blog');
Route::get('/contact', [LandingController::class, 'contact'])->name('landing.contact');
Route::get('/testimonials', [LandingController::class, 'testimonials'])->name('landing.testimonials');

/*
|--------------------------------------------------------------------------
| Admin (template Xeloro) -> URL diawali /admin, nama route diawali admin.
|--------------------------------------------------------------------------
*/

Route::prefix('admin')->name('admin.')->group(function () {
    Route::get('/', [AdminController::class, 'index'])->name('dashboard');
    Route::get('/tables', [AdminController::class, 'tables'])->name('tables');
    Route::get('/forms', [AdminController::class, 'forms'])->name('forms');
    Route::get('/calendar', [AdminController::class, 'calendar'])->name('calendar');
    Route::get('/sweetalerts', [AdminController::class, 'sweetalerts'])->name('sweetalerts');
    Route::get('/login', [AdminController::class, 'login'])->name('login');
});

/*
|--------------------------------------------------------------------------
| Landing Page ke-2 (template Movflx) -> URL diawali /movflx, nama route diawali movflx.
|--------------------------------------------------------------------------
*/

Route::prefix('movflx')->name('movflx.')->group(function () {
    Route::get('/', [MovflxController::class, 'index'])->name('home');
    Route::get('/movie', [MovflxController::class, 'movie'])->name('movie');
    Route::get('/tv-show', [MovflxController::class, 'tvshow'])->name('tvshow');
    Route::get('/pricing', [MovflxController::class, 'pricing'])->name('pricing');
    Route::get('/blog', [MovflxController::class, 'blog'])->name('blog');
    Route::get('/contact', [MovflxController::class, 'contact'])->name('contact');
});

/*
|--------------------------------------------------------------------------
| Admin ke-2 (template Snacked) -> URL diawali /snacked, nama route diawali snacked.
|--------------------------------------------------------------------------
*/

Route::prefix('snacked')->name('snacked.')->group(function () {
    Route::get('/', [SnackedController::class, 'index'])->name('dashboard');
    Route::get('/tables', [SnackedController::class, 'tables'])->name('tables');
    Route::get('/forms', [SnackedController::class, 'forms'])->name('forms');
    Route::get('/charts', [SnackedController::class, 'charts'])->name('charts');
    Route::get('/calendar', [SnackedController::class, 'calendar'])->name('calendar');
    Route::get('/login', [SnackedController::class, 'login'])->name('login');
});
